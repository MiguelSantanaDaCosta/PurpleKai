#include "parser.h"
#include "lexer.h"
#include <cctype>
#include <algorithm>
#include <initializer_list>
#include <iostream>

//=================================================
//IMPLEMENTAÇÃO DOS METODOS AUXILIARES
//=================================================
Parser::Parser(const std::vector<Token>& tokens)
  : tokens_(tokens){}


  /** Verifica se chegamos ao final da lista de tokens
   * @return true se o token atual é END_OF_FILE
   */
  bool Parser::isAtEnd() const {
    return peek().type == TokenType::FIN_FICHIER;
  }

/** Avança para o proximo token e retorna o token anterior
 * @return Token consumido
 */ 

const Token& Parser::advance(){
  if(!isAtEnd()) current_++;
  return previous();
}

/** Obtém o token atual sem consumi-lo (loookhead)
 * @return Token atual
 */
const Token& Parser::peek() const {
  return tokens_[current_];
}

/** Verifica e consume o token se for do tipo especificado
 * @param type Tipo de token esperado
 * @return true se o token foi consumido
 */

bool Parser::match(TokenType type){
  if (check(type)){
    advance();
    return true;
  }
  return false;
}


const Token& Parser::previous() const {
    return tokens_[current_ - 1];
}
/** Verifivca e consome se qualquer um dos tipos corresponder
 * @param types Lista de tipos possiveis
 * @return true se algumn token foi consumido
 */

bool Parser::match(const std::initializer_list<TokenType>& types){
  for (TokenType type : types){
    if (check(type)){
      advance();
      return true;
    }
  }
  return false;
}

/** Consume obrigatoriamente um token do tipo especificado
 * @param type Tipo esperado
 * @param message Mensagem de erro se não corresponder
 * @return Token consumido
 * @throws ParseError se o tipo não corresponder
 */
const Token& Parser::consume(TokenType type, const std::string& message){
  if (check(type)) return advance();
  throw error(peek(), message);

}

/** Cria um objeto de erro de parsing
 * @param token Token onde ocorreu o error
 * @param message Descriçaõ do erro
 * @return Objeto ParseError
 */
ParseError Parser::error(const Token& token, const std::string& message) const{
  return ParseError(token, "[Linha"+ std::to_string(token.line)+ "]" + message);

}

/** Sincronoza após um erro - avança até encontrar um ponto de recuperação 
 * Pontos de recuperação: inicios de declarações( class, func, var, etc.)
 */
void Parser::synchronize(){
  advance();//Avança pelo token problematico

  //Continua avançado até achar um ponto de Sincronozaçaõ 
  while(!isAtEnd()){
    if (previous().type == TokenType::SEMICOLON) return;

    switch (peek().type){
        case TokenType::CLASSE:
        case TokenType::FONCTION:
        case TokenType::LAISSER:
        case TokenType::CONSTANTE:
        case TokenType::SI:
        case TokenType::POUR:
        case TokenType::TANTQUE:
        case TokenType::RETOURNER:
             return;
       default:
             advance();

    }
  }

}

//=========================================================================
//Métodos de parsing de declarações(top-level)
//========================================================================
//
/** Método principal que inicia o parsing do programa
 * @return AST do programa (nó raiz do Program)
 */
std::unique_ptr<Program> Parser::parse(){
  auto program = std::make_unique<Program>();

  //Processa todas as declarações até o final do arquivo]
  while (!isAtEnd()){
    try{
      program->declarations.push_back(parseDeclaration());
    }catch ( const ParseError& e){
      //reporta o erro e Sincronoza para tentat Continuar
      std::cerr << e.what() << std::endl;
      synchronize();

      //Em produção, coletaria todos os erros antes de abortar
      throw;

      }
    }
    return program;
  
}

/** Parseia uma declaraçaõ de alto nivel
 * @return Declaração (class, func, var ou statement)
 */

StmtPtr Parser::parseDeclaration(){
  if (match(TokenType::CLASSE))   return parseClasseDeclaration();
  if (match(TokenType::FONCTION)) return parseFunctionDeclaration();
  if (match({TokenType::LAISSER, TokenType::CONSTANTE})){
  //Retrocede pois o token já foi consumido pelo match 
     current_--;
     return parseVarDeclaration();
  }
  return parseStatement();
}



/** Parseia declaração de classe 
 * Formato: "classe" ID [herite ID] "{" {método} "}"
 */
std::unique_ptr<ClassDec1> Parser::parseClasseDeclaration() {Token name = consume(TokenType::IDENTIFIANT, "Esperado nome da classe após 'classe'");
    // Herança opcional
    std::unique_ptr<VariableExpr> superclass = nullptr;
    if (match(TokenType::HERITE)) {
        Token superName = consume(TokenType::IDENTIFIANT, "Esperado nome da superclasse após 'herite'");
        superclass = std::make_unique<VariableExpr>();
        superclass->value = superName; 
    }
    
    consume(TokenType::LEFT_BRACE, "Esperado '{' antes do corpo da classe");

    // Parseia os métodos da classe
    std::vector<std::unique_ptr<FunctionDec1>> methods;
    while (!check(TokenType::RIGHT_BRACE) && !isAtEnd()) {
        methods.push_back(parseFunctionDeclaration());
    }

    consume(TokenType::RIGHT_BRACE, "Esperado '}' após o corpo da classe");

    auto classDec = std::make_unique<ClassDec1>();
    classDec->name = name;
    classDec->superclass = std::move(superclass);
    classDec->methods = std::move(methods);
    
    return classDec;
}

std::unique_ptr<FunctionDec1> Parser::parseFunctionDeclaration(){
   Token name = consume(TokenType::IDENTIFIANT, "Expect function name after 'fonction',.");
   consume(TokenType::LEFT_PAREN, "Expect '(' after fnuction name.");

   std::vector<Token> params;
   if (!check(TokenType::RIGHT_PAREN)){
     do{
       if (params.size() >= 255){
         reportError(peek(), "Can't have more than 255 parameters.");
       }
       Token param = consume(TokenType::IDENTIFIANT, "Expect parameter name");
       params.push_back(param);
     }while (match(TokenType::COMMA));
   }
   consume(TokenType::RIGHT_PAREN, "Expect ')' after parameters");

   //Optonal return type
   std::unique_ptr<Type> returnType = nullptr;
   if (match(TokenType::COLON)){
     returnType = parseType();
   }
    
   //Parse functional body
   consume(TokenType::LEFT_BRACE, "Expect '{' before function body.");
   auto body = parseBlock();

   return std::make_unique<FunctionDec1>(name, std::move(params), std::move(returnType), std::move(body));
}

 std::unique_ptr<Type> Parser::parseType() {
    if (match(TokenType::INT)) return std::make_unique<Type>(TypeKind::INT);
    if (match(TokenType::FLOAT)) return std::make_unique<Type>(TypeKind::FLOAT);
    if (match(TokenType::BOOL)) return std::make_unique<Type>(TypeKind::BOOL);
    if (match(TokenType::STRING)) return std::make_unique<Type>(TypeKind::STRING);
    if (match(TokenType::VOID)) return std::make_unique<Type>(TypeKind::VOID);
    
    if (match(TokenType::IDENTIFIANT)) {
        return std::make_unique<Type>(TypeKind::CLASS, previous());
    }
    
    if (match(TokenType::CHOCHET_OUVRANT)) {
        auto elementType = parseType();
        consume(TokenType:: CHOCHET_FERMANT, "Expect ']' after list type.");
        return std::make_unique<Type>(TypeKind::LIST, std::move(elementType));
    }
    
    throw error(peek(), "Invalid type specification");
}

StmtPtr Parser::parseWhileStatement() {
    consume(TokenType::LEFT_PAREN, "Expect '(' after 'tantque'.");
    auto condition = parseExpression();
    consume(TokenType::RIGHT_PAREN, "Expect ')' after condition.");
    
    auto body = parseStatement();
    return std::make_unique<WhileStmt>(std::move(condition), std::move(body));
}

StmtPtr Parser::parseReturnStatement() {
    Token keyword = previous();
    ExprPtr value = nullptr;
    
    if (!check(TokenType::SEMICOLON)) {
        value = parseExpression();
    }
    
    consume(TokenType::SEMICOLON, "Expect ';' after return value.");
    return std::make_unique<ReturnStmt>(keyword, std::move(value));
}

void Parser::reportError(const Token& token, const std::string& message) {
    std::cerr << "[Line " << token.line << "] Error: " << message << "\n";
    hadError = true;
} 

//========================================================================
// REGRAS DE EXPRESSÕES (COM PRECEDÊNCIA)
//========================================================================

ExprPtr Parser::parseExpression() {
    return parseAssigment();
}

ExprPtr Parser::parseAssigment() {
    ExprPtr expr = parseOr();

    if (match(TokenType::EGAL)) {
        Token equals = previous();
        ExprPtr value = parseAssigment();

        // Verifica se a expressão à esquerda é uma variável válida para receber atribuição
        if (auto varExpr = dynamic_cast<VariableExpr*>(expr.get())) {
            Token name = varExpr->value;
            auto assignExpr = std::make_unique<AssignExpr>();
            assignExpr->name = name;
            assignExpr->valeu = std::move(value); 
            return assignExpr;
        }

        error(equals, "Alvo de atribuição inválido.");
    }

    return expr;
}

ExprPtr Parser::parseOr() {
    ExprPtr expr = parseAnd();

    while (match(TokenType::OU)) {
        Token op = previous();
        ExprPtr right = parseAnd();
        auto logical = std::make_unique<LogicalExpr>();
        logical->left = std::move(expr);
        logical->op = op;
        logical->right = std::move(right);
        expr = std::move(logical);
    }

    return expr;
}

ExprPtr Parser::parseAnd() {
    ExprPtr expr = parseEquality();

    while (match(TokenType::ET)) {
        Token op = previous();
        ExprPtr right = parseEquality();
        auto logical = std::make_unique<LogicalExpr>();
        logical->left = std::move(expr);
        logical->op = op;
        logical->right = std::move(right);
        expr = std::move(logical);
    }

    return expr;
}

ExprPtr Parser::parseEquality() {
    ExprPtr expr = parseComparison();

    while (match({TokenType::DIFFERENT, TokenType::EGAL_EGAL})) {
        Token op = previous();
        ExprPtr right = parseComparison();
        auto binary = std::make_unique<BinaryExpr>();
        binary->left = std::move(expr);
        binary->op = op;
        binary->right = std::move(right);
        expr = std::move(binary);
    }

    return expr;
}

ExprPtr Parser::parseComparison() {
    ExprPtr expr = parseTerm();

    while (match({TokenType::SUPERIEUR, TokenType::SUP_EGAL, TokenType::INFERIEUR, TokenType::INF_EGAL})) {
        Token op = previous();
        ExprPtr right = parseTerm();
        auto binary = std::make_unique<BinaryExpr>();
        binary->left = std::move(expr);
        binary->op = op;
        binary->right = std::move(right);
        expr = std::move(binary);
    }

    return expr;
}

ExprPtr Parser::parseTerm() {
    ExprPtr expr = parseFactor();

    while (match({TokenType::MOINS, TokenType::PLUS})) {
        Token op = previous();
        ExprPtr right = parseFactor();
        auto binary = std::make_unique<BinaryExpr>();
        binary->left = std::move(expr);
        binary->op = op;
        binary->right = std::move(right);
        expr = std::move(binary);
    }

    return expr;
}

ExprPtr Parser::parseFactor() {
    ExprPtr expr = parseUnary();

    while (match({TokenType::DIVISE, TokenType::FOIS, TokenType::PERCENT})) {
        Token op = previous();
        ExprPtr right = parseUnary();
        auto binary = std::make_unique<BinaryExpr>();
        binary->left = std::move(expr);
        binary->op = op;
        binary->right = std::move(right);
        expr = std::move(binary);
    }

    return expr;
}


ExprPtr Parser::parseUnary() {
    if (match({TokenType::NON, TokenType::MOINS})) {
        Token op = previous();
        ExprPtr right = parseUnary();
        auto unary = std::make_unique<UnaryExpr>();
        unary->op = op;
        unary->right = std::move(right);
        return unary;
    }
    return parseCall();
}

ExprPtr Parser::parseCall() {
    ExprPtr expr = parsePrimary();

    while (true) {
        if (match(TokenType::LEFT_PAREN)) {
            expr = finishCall(std::move(expr));
        } else {
            break;
        }
    }

    return expr;
}

ExprPtr Parser::parsePrimary() {
    if (match(TokenType::VRAI)) {
        auto expr = std::make_unique<LiteralExpr>();
        expr->value = Value(true);
        return expr;
    }
    if (match(TokenType::FAUX)) {
        auto expr = std::make_unique<LiteralExpr>();
        expr->value = Value(false);
        return expr;
    }
    if (match(TokenType::NULLE)) {
        auto expr = std::make_unique<LiteralExpr>();
        expr->value = Value();  // nil
        return expr;
    }

    if (match(TokenType::NOMBRE)) {
        auto expr = std::make_unique<LiteralExpr>();
        int intValue = std::stoi(previous().lexeme);
        expr->value = Value(intValue);
        return expr;
    }
    if (match(TokenType::DECIMAL)) {
        auto expr = std::make_unique<LiteralExpr>();
        double doubleValue = std::stod(previous().lexeme);
        expr->value = Value(doubleValue);
        return expr;
    }
    if (match(TokenType::CHAINE)) {
        auto expr = std::make_unique<LiteralExpr>();
        expr->value = Value(previous().lexeme);
        return expr;
    }

    if (match(TokenType::IDENTIFIANT)) {
        auto expr = std::make_unique<VariableExpr>();
        expr->value = previous();
        return expr;
    }

    if (match(TokenType::LEFT_PAREN)) {
        ExprPtr expr = parseExpression();
        consume(TokenType::RIGHT_PAREN, "Esperado ')' após a expressão.");
        auto group = std::make_unique<GroupingExpr>();
        group->right = std::move(expr);
        return group;
    }

    throw error(peek(), "Esperada uma expressão.");
}


// Método auxiliar para construir a chamada de função
ExprPtr Parser::finishCall(ExprPtr callee) {
    std::vector<ExprPtr> arguments;
    if (!check(TokenType::RIGHT_PAREN)) {
        do {
            if (arguments.size() >= 255) {
                error(peek(), "Não pode haver mais de 255 argumentos.");
            }
            arguments.push_back(parseExpression());
        } while (match(TokenType::COMMA));
    }

    Token paren = consume(TokenType::RIGHT_PAREN, "Esperado ')' após argumentos.");
    
    auto callExpr = std::make_unique<CallExpr>();
    callExpr->callee = std::move(callee);
    callExpr->paren = paren;
    callExpr->arguments = std::move(arguments);
    
    return callExpr;
}

// ==========================================
// MÉTODOS FALTANTES NO PARSER
// ==========================================

bool Parser::check(TokenType type) const {
    if (isAtEnd()) return false;
    return peek().type == type;
}

std::unique_ptr<VarDec1> Parser::parseVarDeclaration() {
    bool isConst = match(TokenType::CONSTANTE);
    if (!isConst) consume(TokenType::LAISSER, "Esperado 'laisser' ou 'constant'");
    
    Token name = consume(TokenType::IDENTIFIANT, "Esperado nome da variável");
    ExprPtr initializer = nullptr;
    
    if (match(TokenType::EGAL)) {
        initializer = parseExpression();
    }
    
    consume(TokenType::SEMICOLON, "Esperado ';' após declaração de variável");
    auto varDec = std::make_unique<VarDec1>();
    varDec->name = name;
    varDec->initializer = std::move(initializer);
    varDec->isConst = isConst;
    return varDec;
}

StmtPtr Parser::parseStatement() {
    if (match(TokenType::SI)) return parseIfStatement();
    if (match(TokenType::POUR)) return parseForStatement();
    if (match(TokenType::TANTQUE)) return parseWhileStatement();
    if (match(TokenType::RETOURNER)) return parseReturnStatement();
    if (match(TokenType::LEFT_BRACE)) return parseBlock();
    if (match(TokenType::BREAK)) {
        consume(TokenType::SEMICOLON, "Expected ';' after break");
        return std::make_unique<BreakStmt>();
    }
    if (match(TokenType::CONTINUE)) {
        consume(TokenType::SEMICOLON, "Expected ';' after continue");
        return std::make_unique<ContinueStmt>();
    }
    return parseExprStmt();
}

StmtPtr Parser::parseExprStmt() {
    ExprPtr expr = parseExpression();
    consume(TokenType::SEMICOLON, "Esperado ';' após expressão.");
    auto stmt = std::make_unique<ExprStmt>();
    stmt->expression = std::move(expr);
    return stmt;
}

std::unique_ptr<BlockStmt> Parser::parseBlock() {
    auto block = std::make_unique<BlockStmt>();
    while (!check(TokenType::RIGHT_BRACE) && !isAtEnd()) {
        block->statements.push_back(parseDeclaration());
    }
    consume(TokenType::RIGHT_BRACE, "Esperado '}' após o bloco.");
    return block;
}

StmtPtr Parser::parseIfStatement() {
    consume(TokenType::LEFT_PAREN, "Esperado '(' após 'si'.");
    ExprPtr condition = parseExpression();
    consume(TokenType::RIGHT_PAREN, "Esperado ')' após condição do 'si'.");
    
    StmtPtr thenBranch = parseStatement();
    StmtPtr elseBranch = nullptr;
    if (match(TokenType::SINON)) {
        elseBranch = parseStatement();
    }
    
    auto ifStmt = std::make_unique<IfStmt>();
    ifStmt->condition = std::move(condition);
    ifStmt->thenBranch = std::move(thenBranch);
    ifStmt->elseBranch = std::move(elseBranch);
    return ifStmt;
}

StmtPtr Parser::parseForStatement() {
    consume(TokenType::LEFT_PAREN, "Esperado '(' após 'pour'.");
    
    StmtPtr initializer;
    if (match(TokenType::SEMICOLON)) {
        initializer = nullptr;
    } else if (match({TokenType::LAISSER, TokenType::CONSTANTE})) {
        current_--; // Volta para o parseVarDeclaration consumir
        initializer = parseVarDeclaration();
    } else {
        initializer = parseExprStmt();
    }

    ExprPtr condition = nullptr;
    if (!check(TokenType::SEMICOLON)) {
        condition = parseExpression();
    }
    consume(TokenType::SEMICOLON, "Esperado ';' após condição do loop.");

    ExprPtr increment = nullptr;
    if (!check(TokenType::RIGHT_PAREN)) {
        increment = parseExpression();
    }
    consume(TokenType::RIGHT_PAREN, "Esperado ')' após cláusulas do 'pour'.");

    StmtPtr body = parseStatement();

    auto forStmt = std::make_unique<ForStmt>();
    forStmt->initializer = std::move(initializer);
    forStmt->condition = std::move(condition);
    forStmt->increment = std::move(increment);
    forStmt->body = std::move(body);
    return forStmt;
}
